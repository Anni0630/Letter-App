// import "../styles/Drive.css";

function Drive() {
  return (
    <div className="drive-container">
      <h2>Google Drive Files</h2>
      <p>No files uploaded yet.</p>
    </div>
  );
}

export default Drive;
