import { useState, useEffect } from "react";
import { Editor } from "@tinymce/tinymce-react";
import axios from "axios";
import './Editor.css';
import Logout from './Logout';

const LetterEditor = () => {
  const [content, setContent] = useState("");
  const [title, setTitle] = useState("");
  const [letters, setLetters] = useState([]);
  const [selectedLetterId, setSelectedLetterId] = useState(null);

  useEffect(() => {
    axios
      .get("http://localhost:5000/letters", {
        withCredentials: true,
        headers: {
          "Content-Type": "application/json"
        }
      })
      .then((response) => {
        if (response.data && Array.isArray(response.data)) {
          setLetters(response.data);
        } else {
          console.error("Unexpected response format:", response);
          setLetters([]);
        }
      })
      .catch((error) => {
        if (error.response) {
          if (error.response.status === 404) {
            console.warn("No letters found.");
            setLetters([]); 
          } else {
            console.error("Error fetching letters:", error.response.status);
          }
        } else {
          console.error("Network error:", error);
        }
        setLetters([]); 
      });
  }, []);

  // Handle editor change
  const handleEditorChange = (newContent) => {
    setContent(newContent);
  };

  const token = localStorage.getItem("token");

  // Save letter to backend
  const saveLetter = async () => {
    try {
      const data = { title, content };
      if (selectedLetterId) {
        await axios.put(`http://localhost:5000/letters/${selectedLetterId}`, data, { withCredentials: true });
      } else {
        await axios.post("http://localhost:5000/letters/save", data, {
          withCredentials: true,
          headers: {
            // Authorization: `Bearer ${token}`, 
            "Content-Type": "application/json",
          },
        })
          .then(response => console.log("Saved successfully!", response))
          .catch(error => console.error("Save Error:", error));
      }
      alert("Letter saved successfully!");
      // window.location.reload(); 
    } catch (error) {
      console.error("Save Error:", error);
    }
  };

  return (
    
    <div className="editor-container">
       <div className="header">
      <Logout />
    </div>
      <input
        type="text"
        placeholder="Title"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
      />
      <Editor
        apiKey="r1zk8rboxcq0v4sacsnuj1adki0cbivmgsyjo0hxz9df97gb" 
        value={content}
        init={{
          height: 300,
          menubar: false,
          plugins: ["lists", "link"],
          toolbar: "undo redo | bold italic | bullist numlist",
        }}
        onEditorChange={handleEditorChange}
      />
      <button onClick={saveLetter}>{selectedLetterId ? "Update Draft" : "Save Draft"}</button>

      <h3>Saved Drafts</h3>
      <ul>
        {letters.length > 0 ? (
          letters.map((letter) => (
            <li key={letter.id} onClick={() => {
              setTitle(letter.title);
              setContent(letter.content);
              setSelectedLetterId(letter.id);
            }}>
              {letter.title}
            </li>
          ))
        ) : (
          <p>No letters yet</p>
        )}
      </ul>
    </div>
  );
};

export default LetterEditor;
