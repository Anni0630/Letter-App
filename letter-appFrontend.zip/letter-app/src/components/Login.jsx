import { GoogleLogin } from '@react-oauth/google';
import axios from 'axios';
import { useNavigate } from "react-router-dom";
import './Login.css';  

const GoogleAuth = () => {
    const navigate = useNavigate();

    const handleLoginSuccess = async (response) => {
        console.log('Google Token:', response.credential);
        try {
            const res = await axios.post("http://localhost:5000/auth/google", 
                { token: response.credential }, 
                { withCredentials: true } 
            );
            console.log('Server Response:', res.data);
            console.log('Data', res);

            navigate("/editor");
        } catch (error) {
            console.error('Login Error:', error);
        }
    };

    return (
        <div className="google-auth-container">
            <h2>Sign in with Google</h2>
            <div className="google-login-button">
                <GoogleLogin 
                    onSuccess={handleLoginSuccess} 
                    onError={() => console.log('Login Failed')} 
                />
            </div>
        </div>
    );
};

export default GoogleAuth;
