import { Navigate, Outlet } from 'react-router-dom';
import { useEffect, useState } from 'react';
import axios from 'axios';

const PrivateRoute = () => {
    const [isAuthenticated, setIsAuthenticated] = useState(null);

    useEffect(() => {
        axios.get('http://localhost:5000/auth/validate', { withCredentials: true })
            .then(response => setIsAuthenticated(response.data.success))
            .catch(() => setIsAuthenticated(false));
    }, []);

    if (isAuthenticated === null) return <p>Loading...</p>;
    return isAuthenticated ? <Outlet /> : <Navigate to="/" />;
};

export default PrivateRoute;
