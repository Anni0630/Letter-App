import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { GoogleOAuthProvider } from '@react-oauth/google';
import GoogleAuth from './components/Login';
import LetterEditor from './components/Editor';

const clientId = "523505597802-scp7asjjni0hq0vdqlc1oes2qqtg3uus.apps.googleusercontent.com";  // Replace with actual Client ID

function App() {
  return (
    <GoogleOAuthProvider clientId={clientId}>
      <Router>
        <Routes>
          <Route path="/" element={<GoogleAuth />} />
          <Route path="/editor" element={<LetterEditor />} />
        </Routes>
      </Router>
    </GoogleOAuthProvider>
  );
}

export default App;
